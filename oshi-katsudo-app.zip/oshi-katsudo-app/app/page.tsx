import App from "@/components/App";

export default function Page() {
  return <App />;
}
